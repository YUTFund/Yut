import React from "react";

export default function Home() {
  return (
    <div className="bg-white text-gray-900 font-sans">
      <section className="bg-gradient-to-r from-teal-500 to-blue-600 text-white py-20 px-4 text-center">
        <h1 className="text-4xl md:text-6xl font-bold mb-4">YUT Fund</h1>
        <p className="text-xl md:text-2xl max-w-2xl mx-auto">
          Building Digital Economies for Real Jobs
        </p>
        <p className="mt-6 max-w-xl mx-auto">
          A community-driven token funding powerful software platforms that generate income — and channel that income into real-world job creation.
        </p>
        <button className="mt-8 bg-white text-blue-600 font-semibold px-6 py-3 rounded-2xl shadow-md hover:bg-gray-200">
          Buy $YUT Token
        </button>
      </section>

      <section className="py-16 px-4 max-w-4xl mx-auto text-center">
        <h2 className="text-3xl font-bold mb-4">What is YUT Fund?</h2>
        <p>
          YUT Fund is more than a token — it’s a movement. We use crypto to fuel the creation of online tools and marketplaces that help people earn money from anywhere. The income from those tools will power physical job creation in communities that need it most.
        </p>
      </section>

      <section className="bg-gray-100 py-16 px-4 text-center">
        <h2 className="text-3xl font-bold mb-6">Tokenomics</h2>
        <ul className="max-w-2xl mx-auto space-y-2 text-left">
          <li><strong>Total Supply:</strong> 1 Billion $YUT</li>
          <li><strong>Presale:</strong> 40%</li>
          <li><strong>Development:</strong> 20%</li>
          <li><strong>Team:</strong> 10%</li>
          <li><strong>Reserve:</strong> 10%</li>
          <li><strong>Community:</strong> 10%</li>
          <li><strong>Liquidity:</strong> 10%</li>
        </ul>
      </section>

      <section className="py-16 px-4 max-w-4xl mx-auto text-center">
        <h2 className="text-3xl font-bold mb-6">Roadmap</h2>
        <div className="grid gap-4 md:grid-cols-2 text-left">
          <div className="bg-white p-4 rounded-2xl shadow">
            <h3 className="font-bold text-lg">Q1</h3>
            <p>Token Launch, Community Building</p>
          </div>
          <div className="bg-white p-4 rounded-2xl shadow">
            <h3 className="font-bold text-lg">Q2</h3>
            <p>MVP Online Platform (Freelance or Store)</p>
          </div>
          <div className="bg-white p-4 rounded-2xl shadow">
            <h3 className="font-bold text-lg">Q3</h3>
            <p>Platform Revenue & Token Integration</p>
          </div>
          <div className="bg-white p-4 rounded-2xl shadow">
            <h3 className="font-bold text-lg">Q4</h3>
            <p>Physical Job Project Pilots Begin</p>
          </div>
        </div>
      </section>

      <section className="bg-blue-50 py-12 px-4 text-center">
        <h2 className="text-3xl font-bold mb-4">Join the Community</h2>
        <p className="mb-6">Be part of the mission. Stay updated and get involved.</p>
        <div className="flex justify-center gap-4">
          <a href="#" className="text-blue-600 underline">Telegram</a>
          <a href="#" className="text-blue-600 underline">Twitter</a>
          <a href="#" className="text-blue-600 underline">Discord</a>
        </div>
      </section>

      <footer className="text-center py-6 text-sm text-gray-500">
        &copy; {new Date().getFullYear()} YUT Fund. All rights reserved.
      </footer>
    </div>
  );
}